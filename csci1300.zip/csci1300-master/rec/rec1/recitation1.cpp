#include <iostream>
using namespace std;

int main(){
    int coursenumber;
    cin>>coursenumber;
    cout << "Hello, CS" << coursenumber << " world";
    return 0;
}
