int classGreeting(float classnumber){
    
    cout << "Hello, CS" << coursenumber << " world";
    
    return 0;
}
