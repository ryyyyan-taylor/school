#include <iostream>
#include <string>
using namespace std;

int arrays(){
    
    float temps[10] = -459.67;
    
    string colors[5] = {“Red”, “Blue”, “Green”, “Cyan”, “Magenta”};
    
    int sequence[100];
        for(i=1; i<=100, i++)
            sequence[i] = i;
    
}