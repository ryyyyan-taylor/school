#include <iostream>
#include <string>
using namespace std;

int split(string input, char sep, string words[], int max){
    
    for(int i=0; i<input.length; i++){
        
    
    
    
}