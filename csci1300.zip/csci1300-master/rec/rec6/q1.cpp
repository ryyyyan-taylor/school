#include <iostream>
#include <string>
using namespace std;

int arrays(){
    
    int arrayOne[49];
    float arrayTwo[]
    
    
}