#include <iostream>
using namespace std;

int main(){
    int test = 9;
    cout<<test/2;
}