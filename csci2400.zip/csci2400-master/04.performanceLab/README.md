# Performance Lab

The objective here was to optimize the performance of an image editing program. The only thing we had to edit was the **applyFilter** function in **FilterMain.cpp**