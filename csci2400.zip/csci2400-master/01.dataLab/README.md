# Data Lab

This was our first "lab", which were each essentially multi-week long mini-projects.

The data lab dealth with simple bit manipulation of binary numbers to implement some common bitwise actions, such as &, !, finding a certain bit, and dividing by powers of two.

I implemented all the functions in **bits.c** and then an autograder script would run and test each function. Each function also had a maximum number of operators we were allowed to use in the comments preceeding it.
