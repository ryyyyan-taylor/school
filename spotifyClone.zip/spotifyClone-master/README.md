# spotifyClone

**AS OF SEPTEMBER 2019, BILLBOARD UPDATED THE FORMAT OF THEIR WEBSITE AND THE WEB-SCRAPING PORTION OF THIS PROJECT NO LONGER FUNCTIONS**

My final project from my Data Structuers (CSCI2270) course from the Spring of 2019. This project uses a Python web scraping script to grab the top songs from the Billboard Top 100, which are then read into a ranked linked list, with which we can perform many actions. This was meant to emulate the effectiveness of Spotify, the popular music streaming platform.
