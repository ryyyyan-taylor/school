#include <iostream>
using namespace std;

int main(){
     int g = 5;
     int* j = &g;
     cout<<*j<<endl;
}
