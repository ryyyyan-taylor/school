# csci2824

Discrete Structures at CU Boulder. Even number HWs are written assignments typed out in LaTeX, odd numbered assignments had an online component and included here is the answers to the coding question on those.
