# csci3202 - Intro to Artificial Intelligence  
Spring 2022 @ CU Boulder
