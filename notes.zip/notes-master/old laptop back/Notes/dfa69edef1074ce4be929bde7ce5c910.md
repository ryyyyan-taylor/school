PSCI 4012 Global Development

id: dfa69edef1074ce4be929bde7ce5c910
created_time: 2021-08-24T21:12:14.535Z
updated_time: 2021-08-24T21:12:30.258Z
user_created_time: 2021-08-24T21:12:14.535Z
user_updated_time: 2021-08-24T21:12:30.258Z
encryption_cipher_text: 
encryption_applied: 0
parent_id: 
is_shared: 0
share_id: 
type_: 2