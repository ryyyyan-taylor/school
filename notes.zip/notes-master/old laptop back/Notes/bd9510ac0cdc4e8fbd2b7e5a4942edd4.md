id: bd9510ac0cdc4e8fbd2b7e5a4942edd4
parent_id: f95d27d7052e4c0aa0969e57bd9a266f
item_type: 1
item_id: baf05c17f5c3474bb1b8c338d22112cd
item_updated_time: 1629827729888
title_diff: "[]"
body_diff: "[{\"diffs\":[[0,\"side -> fact\"],[1,\"\\\n- Normative versus legal views\\\n\\t- need separation between personal \\\"beliefs\\\" and what the law says\\\n\\t- arguable -> not true\\\n\\t\\t- guess normative views from statement -> normative argument\\\n\\t- legal argument: base evidence is text of the law\\\n\\t\\t- need argument rooted in the black and white text of the case law\\\n\\t\\t- grey area which exists in the root interepretation of words\"]],\"start1\":148,\"start2\":148,\"length1\":12,\"length2\":383}]"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-08-24T18:04:29.346Z
created_time: 2021-08-24T18:04:29.346Z
type_: 13