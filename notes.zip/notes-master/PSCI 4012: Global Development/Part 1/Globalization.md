# Globalization

09/09/21



- cross border trade in goods and services
    key terms:
- Financial Capital Mobility
    - cross border transfer of capital
- labor migration

## Global trade 1800-1914

- hegemonic british leadership
  
- global tariff reduction and fixed exchange rates
  
    - gold standards
- west turns away from protectionism
  
- late 1700s/early 1800s wealth is about ability to produce consumable goods
  
- economies operated under assumption of cpmarative advantage
  
- 5 main triggers
  
    - technolgies made trade less expensive and more rapid
    - west needs raw materials to industrialize
    - governments eliminate protectionist policies
    - gold standard
    - mindset more favorable to free trade
    
- global south exporting primary goods
  
    - latin america : beef, coffee, silver, sugar
    - africa/asia : coconuts, gold, ivory, peanuts, rice
- proliferation of mncs occurs
  
    - multi national corporations
- outbreak of WWI first ends first period
  
- west focused on war, demand for global south commodities drops
  

### Comparative Advantage

- country x can produce x commodity at lower opportunity costs than country y
- upshot : trade benefits between parties
- many assumptions : more complications in real world
    - relationsh, transport costs, etc
- idea underpins free trade theory and ftas

## Transition to ISI Based economy

- import substitution industrialization
- late 19th century development of ability to produce raw
- by WWI countries developed economies to export raw materials and imported final goods
- 6 main features
    1.  protective tariffs
    2.  preferences for domestic firms importing capital goods for new industries
    3.  pereferential import exchange rates for raw materials
    4.  cheap loans by govt development banks for favored industries
    5.  govt funded ifastructure to support favored industries
    6.  direct participation of govt in certain industries
        - when there's a need and no one wants to invest
- gdp doubles in latin america 1950-80
- egypt, indonesia, mexico began exporting some final goods
- failures of ISI
    - inefficient business
        - shoddy goods at high prices
    - created inequalities between rural and urban residents
        - crop production declined
        - agrarian support disappeared
        - spurred urbanization but created large underclass
    - few exports led to balance of payment debt crisis
        - overvalluation of currency
        - discrimination against rural sector
        - low quality final goods

## Export promotion

- 1960s/70s : asia moves to export promotion
    - reduce tariffs to increase exports
    - developed light manufactoring to export goods
    - subsidiized export oriented firms
    - devalued currencies, goods became cheaper and exportation is promoted
- predominant in southeast and east asia
  

# Dependency Theory

- powerful in 1960/1970s
- attempt to explain global inequalities
- extensions of colonialism continued though globalization
- unfair trade policies tool to exploit global south
- **terms of trade** : value a country for what it receives in imports in exchange in what it exports
    - hight terms of trade : state can buy many imports compared to its exports
    - terms of trade consistantly declining for gloal south
- world divided between core states and peripheral states
- surplus value : difference between value of good and cost to produce
- core states export final good with high markup
- surplus value is transferred to core state
- marxist/neo marxist on the global scale
- created division in global south small ruling classes
    - managing exploitation of population
- assocaited with latin america countries

## World Systems theory

- wallerstein primary author
- world is one market with division of labor
- sovereign states controlled by global economy
- world is 3 tier structure
    - core
    - periphery
    - semi-periphery
- world system operates in cycles
    - capitalist hegemon emrges
    - capitalists exploit labor
    - periphery : little capital, poorly governed, low wages, low prices for exports
    - international institutions don't do anything
    - extraction
    - as fewer emplyees are needed, consumer markets are lost
    - cycle only ends when capitalists can't make profit

## Financial Services

- portfolio investments
  - lend money to borrower -> invests in stocks
  - positive money can pour into these countries
  - negative capital flight : money can leave fast due to many different reasons
    - conflict, political instability, economic fluctuations, examples of reasons to exit
    - portfolio investment can "take flight" fast because no FDI

# Concerns about Globalization

## Race to the Bottom

- downward pressure placed on economies
- mncs end up controlling economy
- labor laws abolished
- countries become tax havens
- upshot jobs are created, gdp increased, what cost?

### Consequences

- lost labor protection
- more competition between national governments, tax rates expected to decrease
- when tax revenues decline, gov expenditure decreases
- **sweatshops**
  - labor protecton abolished
  - employment goes up, conditions and pay decrease
  - child labor and other human rights violations

## Economic Crises

- many causes
  - elimination of tax rates
  - adoption of model of advanced economies
  - domestic infighting

## Brain Drain

- international migration causes people from developing countries to seek opportunities in advanced economies
  - often most educated portion of population
- in language of capabilities : country has little freedoms to offer

