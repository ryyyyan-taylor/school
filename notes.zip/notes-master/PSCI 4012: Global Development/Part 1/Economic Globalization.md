# Economic Globalization

## Bretton Woods & Postwar (1946-71 ish)

- all currencies pegged to us dollar which was pegged to gold
- golden trilemma
  - during period of globalization
    1. free capital flow
    2. fixed exchange rate
    3. sovereign monetary policy
  - impossible to have all 3
- goal of system :
  - national autonomy : handling inflation, employment etc via domestic monetary policy
  - international stability
- fixed exchange rates
- institutions such as imf assist by regulating trade and money relations
- shift to liberalism
- **GATT** : general agreement on trade and tariffs
  - served as formal structure to postwar global econ
  - was built on principles of increased transactions and interdependence
  - became WTO in 1996

## Washington Consensus

- "one for all" approach to economic development
- policies to benefit highly developed and wealthy nathions
  1. fiscal discipline : limit social spending
  2. financial liberalization
  3. attract foreign direct investment
  4. pirvatization
  5. deregulation of barriers to global economy
  6. trade liberalization
- world bank and imf promoted
  - market fundamentalism : free markets will solve many problems
  - limited gov regulation
- wb and imf forced compliance through conditionality
- structural adjustment programs

