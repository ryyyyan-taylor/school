08/31/21
# Capabilites Approach

## Freedom and justice constitute development
- capabilites : basic needs
	- healthcare
	- education
	- food
	- shelter
	- clothing
	- sanitation
	- securty
	- infastructure
- capability deprivation : lack of money / poverty
- human development : providing basic needs
- conversion factors : factors which affect one's ability to convert a set of means into functionings
- **Freedoms** : few if no conversion factors
	- are there valuable options / alternatives?
	- are opportunites formal or legal?
	- are opportunites effectively available to all?




- criticizes informational bases of traditional economic models

  - originally sen - 1970s
- flexible and multi-purpose approach
	- no unified / concise theory
	- eg. no true list what constitutes basic needs
- 2 real groups of capability theorists
	1. comparative quality of life
	2. theorizing about justic and freedom
- 2 normative claims
	1. *Freedom to achieve well being* is of primary moral improtance
	2. Well-being refers to people's *capabilites and function*
- **Capabilites** are necessities people can realize if they so choose
	- eg. well-fed, marriage, education, travel, etc
- **Functionings** are capabilites that have been realized
- 3 normative exercises
	- assessment of individual well beings
	- assessment of social arrangements
	- proposals / policies encouraging social change

## 5 generally agreed upon principles
1. individual level : treat each person as an end
2. choice and freedom are more important than achievements
3. values vary across groups and change over time
4. deeply concerned with social injustices (critical approach/theory)
5. ascribing an urgent task to government

# Relation between human and economic development
- correlation but no evidence of causal effect
- advances in education and health care tend to occur simultaneous with some degree of economic growth

## Composite indicators
- Human Development Index
	- pros
		- simplicity
		- can be disaggregated
		- represents different approach to development
	- cons
		- does not add to each individual category
		- better to analyze each variable independently
		- indexes are inherently biased
		- loses power to generalize and predict

## Key Indicators
- life expectancy : from birth, based on capabilities at brith
- child mortality : death before 5
- infant mortality : death before 1

### Causes of poor health outcomes
- welfare state : gov't entity seeks to assist in providing basic needs and overcoming defficiencies
- ldcs : less money to spend on health care
- private sector acannot fill gap
- poor water supply
	- no plumbing
	- flushing toilets are rare
	- grey water used for living
	- contagious diseases passed through feces
- results:
	- less trained personnel
	- trained personnel poorly compensated
	- access is less equal
		- rural areas
		- similar in oecd but nowhere near as significant
- outcomes are converging!
	- health outcomes rising ind ldcs
	- life expectancy improving greatly

### Education Indicators
- net enrollment ratio
	- % of particular group enrolled
		- mostly primary and secondary levels (definitions will vary)
- age-specific enrollment ratio
	- participation in education of the population of each particular age regardless of level
- causes of bad:
	- low funding
		- ill equipped schools
	- poor instruction
		- lack of teachers
	- parental decisions / opportunity costs
		- children often work to assist family
- this one converging too!