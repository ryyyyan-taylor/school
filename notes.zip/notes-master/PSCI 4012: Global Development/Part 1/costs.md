# Post Development Theory

- arturo escobar
- west created notion of development to impose ways of life on the rest of the world
- questions centrality of development as goal of social life
	- westernization
	- critical theory
	- wealth vs poor may be western construct
	- cultural norms
	- urbanization casues homogenization to occur faster
- social connectedness lost with development
	- people become attached to jobs, less leisure and family time
- economic reliance on others causes loss of independence
	- specialization
	- workers become a cog in a machine
- increased consumerism
	- people in debt to financial institutions
	- pay interest




- critics
	- people tend to enjoy wider choice of material goods
		- cellphone ownership
	- many non-western countries seek wealth
		- notion that wealth = power
	- specialization brings people together in mutually beneficial exchange
		- discourages discrimination
	- education makes up for many potential perils of specialization


# Slavery and Development
### Countries more affect by slave trade less developed

## Africa
- slave trade slowed population growth
- deepened internal divisions within africa
	- locals kidnapping other locals to force into slave trade
- loss of confidence in leadership
- responses
	- demographic trends can't be attributed to salve trade
		- not large enough scale of forced migration
	- some say regions have lost and did not suffer same lack of development
	- new african states and city states were formed but development did not occur

## Latin America
- political and social arrangements have changed in areas where development isn't occuring
- colonial legacies
	- strict social structure
	- feudal / semi-feudal
	- patriarchal
	- notable excepted people with money
- settler vs non settler colonies
	- settler : large european communities that transformed culture and society
	- non : temporary government officials not planning to stay

## Carribean
- institutiiionalized inequality
- white landowning elite vs "others"
	- landowners desire status quo
	- block progress
	- ex corrupt legal systems, violience, unfair hiring, access to education

## colonialism
- **def** : governing territory by geographically foregin state
- nearly all ldcs have been colonized
- lines drawn during colonialism  for reasons that did not take development into consideration
- impact of religion
	- created power division in countries with large indigenous populations
- **colonial drain** : transfer of wealth from colony back to metropole
	- super heavy taxation
	- transferred treasury funds back to homeland
	- extraction of natural resources
	- forced labor of the poor
	- land transfers