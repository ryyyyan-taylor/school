capabilities thoery : amartya sen, nussbaum

post development theory : escobar

world systems : wallerstein

comparative advantage : ricardo

dependency theory : singer
