# Regime Type and Development

- Regime type : rules that shape how society is governed
- democracy : representation, inclusion, and participation, free and fair elections
- authoritarianism : citizens not involved in politics and decision making
- **Main question** : regime type affect developmental outcome?

