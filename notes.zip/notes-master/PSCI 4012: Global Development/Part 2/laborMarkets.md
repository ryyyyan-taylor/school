# Labor Markets

- institutions : organizations or rules thatt structure human interactions
  - economic : organization or set of rules that structure decisions about the allocation of materials
    - markets, MNCs, imf or wb

## informal economy

- unregulated by the institutions of society aka state

  - unregulated

  - not formally recognized but generally known about

  - sometimes illicit activity

  - sometimes day to day activity

- property institutions

  - property market : gov divides major assets such as housing, land, capital
  - property rights : legal rights to these assets
  - informal settlements : housing on land to which residents have no legal claim
  - customary law : governs theses areas more so than traditional law
  - why?
    - ldcs lack institutional framework to enforce rule of law
    - lacking legal code
    - independent judiciary
    - bureacracy

- problems

  - often temporary / seasonal work
  - no wage enforcement
  - zero benefits
  - gov cannot collect taxes
  - zero regulation

- negatives

  - unproductive small firms
  - not enough formal laborers for formal sector
  - skills not developed along similar lines

- entry costs inhibit transition to formal sector
  - registering a business
  - transportation to and from gov buildings
- ldcs say cost is so high so they can regulate and enforce rule of law
  - ensure capital is being transferred to workers
  - labor / environmental standards
- critics see it as a way fro gov to generate rents for gov bureaucrats and leading firms

## Loans

- lending institutions sometimes don't work in ldcs
- banks and formal institutions infrequently used in ldcs
  - administrative cost of many small loans
  - likelihood borrower will default
- people often borrow from local moneylender
  - loan shark
  - rotating savings and credit associations : pay into fund, savings given to a single member during period on rotating basis
  - microfinance institutions : solidarity lending, loans made to group of lenders, jointly liable for repayments
- banks not always used in ldcs
  - citizens don't trust banks
  - banks don't want meager earnings of poor communities
  - money often kept in house, informal money guards
- negatives
  - informal lending services charge high fees / interest rates
  - loan sharks use violence
  - citizens' savings do not earn interest