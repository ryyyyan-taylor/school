# Exam 2

## Economic development models
```
Be able to explain in detail how different models work
Socialism, Capitalism, State-led Capitalism (EOI and ISI could be asked about because it was in the Baker reading on development models, so review those two models as well)
```
- development model : state policies guiding development / economic strategy
    - state vs private ownership
    - how integrated into global economy
- ISI
    - state led
    - support of domestic industries
    - get away from exporting raw and importing finished : keep that manufacturing local
    - strategic support and subsidies helped industry grow
- EOI
    - similar to isi but with big focus on exports
    - comp low tariffs
    - light manufacturing exports increased
    - more open trade than other regions
- Socialism
    - much bigger state role than isi/eoi
    - rooted in marx
        - Bourgeoise (owners)and proletariat (workers)
        - capitalism will eventually self destruct into socialist system
    - agricultural collectives on jointly owned land
    - communes that operate as collectives
    - central planning decides how system works
        - command economy where central gov makes econ decisions
            - quotas, prices, etc
        - resource allocation by central agency
    - impressive equality
        - large welfare states
        - theoretical more equitable wage distribution
        - theoretical high employment
    - Cuba case study
        - low homelessness
        - low hunger
        - extremely safe : no drugs, trafficking, organized crime
    - ultimate failures
        - human rights abuses
        - collectivization on agriculture specifically
        - limited freedom to advance/achieve
        - often inefficient production
- Washington consensus : push free markets on LDCs
    - main feature : privatization
    - cutbacks in social programs
    - protectionist barriers lifted at gov level
    - failures
        - failed promise of industrialization
        - unemployment rose from privatized firms
- State capitalism
    - open to both private sector and global markets
    - state owned major assets
        - oil, gas, transportation, etc
    - state main actor by owning corporations
    - markets tools to serve national interest
    - critiques
        - state led firms leave no room for smaller
        - stifled innovation/competition?

## Civil war and political violence
```
Know all general info (Baker/Class), conflict trap (Collier) and examples
```
- civil war
    - causes
        - low income
        - slow growth
        - dependence on primary exports
    - collier : war can lead to economic decline and repeath
        - many other popular factors don't matter
            - ethnic strife, colonialism, inequality, geography
    - costs
        - mortality rates
        - infastructure destruction
        - loss of production
- fragile state index

## Criminal violence
```
All general info from Baker/Class
Latin America as case study for violence
Perez discussion about effects on support for democracy (know why his argument matters/be able to link it to regime type discussion)
```
- LA example
    - development and social action needed to mitigate violence

## Regime type
```
In addition to Baker/Class, know that these folks say: Acemoglu/Robinson; Lipset; Przeworski/Limongi
```
- democracy : inclusive
    - Acemoglu/Robinson : democracy DOES cause growth
        - upshot in GDP per capita
        - driven via greather investments in capital, school, health
        - ability to innovate
        - people free to realize potential
    - lipset
        - number of conditions can lead to democracy
        - open class systems, wealth, capitalism
        - democracy leads to open class system, equalitarian values, literacy, etc
    - limongi/przeworksi
        - many other factors can affect development other than regim type
        - state autonomy
- authoritarianism


## Institutions
```
Baker/Class
Acemoglu/Robinson on 'why nations fail'
Inclusive/Extractive institutions (review the assigned readings; DO NOT rely on our early discussion about extractive institutions and colonialism)
```
- extractive : acemoglu/robinson
    - wealth redistributed to small group of elites
    - expropriation
    - petty corruption
    - rent seeking
- inclusive
    - democracy, rule of law
    - wider redistribution
- acemoglu/robinson
    - strong central state with broad distribution of power = development

## Formal and informal labor markets
```
Causes, consequences and all other issues reviews in Baker and class
```
- informal economy
    - unregulated by institutions of society
    - paths in from formal:
        - choose to exit
        - forced out
    - problems
        - temporary work
        - no stable wage enforcement
        - no benefits
        - no tax collection so not helping gov
        - small numbers available jobs
- formal
    - entry costs can be very  : prohibitive for those in informal sector
    - 

## Geography and development (including resource curse)
```
Know arguments of Sachs, Diamond, Collier (discussed in Baker, but see assigned readings for detailed info)
```
- further from equator, more developed (generally)
- Tropical disadvantage
    - easier for illness to spread quickly shutting down lots
    - more difficult food production
- Sachs : lots of different factors
    - distance to ports
    - oil reserves
    - climate
- Diamond : europe got geographical luck
    1. eurasian advantages  
        - larger supply of plants  
        - luckier mix of animals  
        - near fertile crescent
    2. agricultural surplus means industrialazation in all forms
    3. therefore urban living and brought people together
- geography can prove a barrier to exchange and thus specialization