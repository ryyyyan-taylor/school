# Development Models

## Terms

- Development model
  - state policies guiding economic activity
  - overarching economic strategy
- State led development
  - state dominated economy
- private ownership
  - all firms privately owned
- Keynsianism
  - argument for state led economic intervention
  - **fiscal policy** : goverment tax and expenditure policy
    - spending in correct areas to create jobs
  - interest rates and money supply
    - lower interest rates to spur borrowing

## Early - Modern Thought on Development

- poverty trap for ldcs
  - wages low due to excess supply of labor
  - nobody can save or invest
  - no consumer markets
  - bit push strategy: state led
- lack of entrepreneurial / managerial knowledge in ldcs
- state led investment must focus on firms with 
  - create backward linkages supporting producers
  - more backwark links, spur more industry

## State Owned Enterprises

- spurs investment
- do not need to profit
- can support other domestic industries; backward linkages
- can borrow at 0% and remain active
- very common in ldcs
- problems
  - not incentivized to be efficient or profitable
  - can borrow as a bail out : more inefficiency and bad decisions
  - ripe for corruption
    - patronage : putting friends in high positions
- tools to spur development
  - tax credits
  - low interest financing
  - direct payments
  - subsidies

### ISI vs EOI

- supporters of eoi : countries had more open trade policies with other regions
- support for isi : 
  - strategic support helped industries grow
  - subsides help them compete
  - failures of isi not as bad when compared to earlier failures

## Economic Populism

- popular in many ldcs
- promises jobs, wages, worker friendly policies
- redistribution to low and middle income groups
- state spending and wage increases
- price controls
- expansive monetary policy aka print lots of money

## Marketing Boards

- government agencies purchase products and resell to domestic and foreign consumers
- state is the sole buyer of goods

## Socialism

- main exception to isi / eoi
- state role much more expansive than isi eoi
- rooted in marx and class struggles
- agricultural collectives
  - jointly owned land for collective farming
  - crops often sold to the state
- communes
  - self sustaining communities that operate as collectives
- **central planning**
  - central planners decide how the system works
  - command economy : central gov makes all economic decisions
  - setting quotas, prices
  - resources allocated by central agency
    - no market organizing supply chains for entire state
- achieving equality
  - expansive welfare states
  - theoretically more equitable wage distribution
  - redistribution of land via expropriation and collectivization
  - theoretically high employment
- successes
  - impressive social welfare programs
  - impressive human development indicators
  - wages and lifestyles somewhat equalized