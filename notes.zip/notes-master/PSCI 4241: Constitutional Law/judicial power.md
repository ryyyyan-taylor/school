09/09/21

# Independence
- different than judicial power
- same problem as power, very hard to discern sincere preferences
- are judges motivated by personal? or constrained by
	- law
	- other justices or elites
	- public
	- congress
	- president
	- social forces

# Power
- legal model : view that law constrains
	- constrains judicial branch : limits judicial power
	- understanding difference between liberty and rights
- no such thing as judicial activism
	- legislating from the bench
- no such thing as original intent
- no such thing as strict constructionism
- evidence suggests people are not supportive of rights or liberties in general

## Major Debates
- "proper" rule of courts in politics
- ought vs is
	- normative vs causal debates
- political scientists focus on the "is"
	- are courts power (independent)? why
	- can they protect minorities