09/02/21

- two ways of having a dual system
	- **Criminal / Civil**
	- some matters fall under both
		- monetary damages for victims
	- most liberties are criminal / rights are civil
		- liberties: speech, religious activity, etc
- litigation trajectory in dual system
	- State
		1. stuff happens
		2. trial
		3. bunch of appellate courts
		4. state supreme court
	- Federal
		1. stuff happens
		2. trial
		3. circuit courts
		4. us supreme court
- different levels of review
	- constitutional review
		- all legislation and all state actions mst be in accordance with *constitutional principles*
		- highest level of actions in questions is constitutional
		- every court can institute constitutional review
	- statitory review
		- statute : law
		- hight level of actions are governed by statute
		<br><br>

## federal courts have limited jurisdiction
- article III
- court must be able to *do something* to fix issue
	- can't sue for hurt feelings
- must have standing to sue : be hurt by law in question
	- federal judicial power does not exist in the abstract
	- examples
		- Roe v Wade
		- line item veto
			- law stays but omit wrong parts
		- should trees have standing?
		- Lawrence v Texas
		- Craig v Boren
		<br><br>

# supreme court process
- chooses about 70-80 cases from pool of 9000
- law clerks review cert pool : 4 justices vote to grant cert
- interest groups write amici
	- often 600+ per case
	- unknown how much power these actually hold
- oral argument 30 mins each side
- conference
- chief justice is tie-breaker
- opinions
	- majority
		- opinion assignment
		- ideology matters
	- concurring
	- dissenting
- weight of decision
	- 5 justices must sign off to set precedent for future
	- Dicta : insult to rationale
	- Stare decisis'

# Rights vs liberties
- government can not prevent you from doing liberty
- rights are based on classifications
	- can not take or give based on certain classes
	- equality
- government is allowed to discriminate

## Griswold
- diaphragm contraception
- freedom of speech also includes right to distribute, receive, read, and freedom of inquiry, thought, teach : enable entire university community
- without peripheral rights, specific rights would be less secure
- aka first amendment has penumbra where privacy is protected from governmental intrusion
- various gaurantees protect zones of privacy