var express = require('express');
var app = express();
var http = require('http');
var path = require('path');
const bodyParser = require('body-parser');
const { response } = require('express');

app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));

var pgp = require('pg-promise')();

const dbConfig = {
	host: 'localhost',
	port: 5432,
	// database: 'final_db',
	user: 'postgres',
	password: 'password'
};

var db = pgp(dbConfig);

app.get('/', function(req, res) { 

	res.render('pages/main', {
		pageTitle: "Home",
		data: ''
	})
});

app.post('/', function(req, res) {

	var title = req.body.titleField;
	var review = req.body.reviewField;

	var now = new Date();
	now.toISOString().split('T')[0] + ' ' + now.toTimeString().split(' ')[0];

	var insert = "INSERT INTO final_db.reviews(movie_title, review, review_date) VALUES('" + title + "', '" + review + "', CURRENT_TIMESTAMP);";

	db.task('add-review', task => {
		return task.batch([
			task.any(insert)
		]);
	})
	.catch(err => {
		console.log('error adding review', err);
	});

	res.redirect('/reviews');
});

app.get('/reviews', function(req, res) { 

	var query = "SELECT * from final_db.reviews;"

	db.task('get-review', task => {
		return task.batch([
			task.any(query)
		]);
	})
	.then(info => {
		res.render('pages/reviews', {
			pageTitle: "Reviews",
			'data': info[0]
		})
	})
});


app.listen(4000);