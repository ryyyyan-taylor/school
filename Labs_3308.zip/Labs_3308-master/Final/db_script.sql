DROP DATABASE IF EXISTS final_db;
DROP TABLE IF EXISTS final_db.reviews;
DROP SCHEMA IF EXISTS final_db;

CREATE DATABASE final_db;
CREATE SCHEMA final_db;

CREATE TABLE final_db.reviews (
	id SERIAL NOT NULL UNIQUE PRIMARY KEY,
	movie_title VARCHAR(45),
	review VARCHAR(280),
	review_date TIMESTAMP
);

INSERT INTO final_db.reviews(movie_title, review, review_date)
	VALUES('Saw IV', 'this was great', CURRENT_TIMESTAMP);