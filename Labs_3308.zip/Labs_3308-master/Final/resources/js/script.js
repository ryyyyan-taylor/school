function openModal(title) {

	var titleField = document.getElementById("titleField");
	titleField.value = title;
	titleField.readOnly=true;

}

function apiSearch() {
	var results = document.getElementById("results");
	var searchTerm = document.getElementById("searchTerm");
	var term = searchTerm.value.replace(/\s/g, '+');
	var url = `http://www.omdbapi.com/?s=${term}&apikey=719c0cf5`;
	
	results.innerHTML = "";

	console.log(url);

	fetch(url)
		.then((res) => res.json())
		.then((res) => {
			res.Search.forEach((movie) => {
				
				var card = document.createElement("div");
				var movieTitle = document.createElement("h5");
				var cardBody = document.createElement("div");
				var poster = document.createElement("img");
				var reviewButton = document.createElement("a");

				card.className = "card";
				card.style.width = "18rem";
				card.style.margin = "0 1rem 1rem 0";
				card.style.diplay = "inline-block";

				cardBody.className = "card-body";

				movieTitle.className = "card-title";
				movieTitle.innerHTML = movie.Title;

				poster.className = "card-img-top";
				poster.src = movie.Poster;

				reviewButton.className = "btn btn-primary";
				reviewButton.textContent = "Review";
				reviewButton.href = "#reviewModal";
				reviewButton.id = movie.Title;
				reviewButton.setAttribute("data-toggle", "modal");
				reviewButton.setAttribute("onClick", "javascript: openModal(this.id);");

				card.appendChild(poster);
				card.appendChild(cardBody);
				cardBody.appendChild(movieTitle);
				cardBody.appendChild(reviewButton);
				results.appendChild(card);
			});
		});
}

