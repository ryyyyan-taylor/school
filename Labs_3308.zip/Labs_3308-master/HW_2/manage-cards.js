function addCard(pCard) {
	
	var parent = document.getElementById(pCard);

	var tweetCard = document.getElementById("tweet").cloneNode(true);
	tweetCard.style.display = "";

	parent.append(tweetCard);
}