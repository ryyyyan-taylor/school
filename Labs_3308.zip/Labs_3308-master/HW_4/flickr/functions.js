var currentPage = 1;
function makeApiCall() {

  var content = document.getElementById("content"); //empty div, will put cards here
  content.removeEventListener("scroll", checkScroll);
  content.addEventListener("scroll", checkScroll);

  var numDisplay = document.getElementById("numDisplay");
  var searchTerm = document.getElementById("searchTerm");

  // call api with my key, and entered nums and term
  var url = `https://www.flickr.com/services/rest/?method=flickr.photos.search&api_key=f3e1c44e82886ea1babdf2395d26cae9&format=json&nojsoncallback=1&per_page=${numDisplay.value}&page=${currentPage}&tags=${searchTerm.value}&privacy_filter=1&safe_search=1`;

  fetch(url)
    .then((res) => res.json())
    .then((res) => {
      res.photos.photo.forEach((img) => {

        var newCard = document.createElement("div");
        var imageTitle = document.createElement("h5");
        var cardBody = document.createElement("div");
        var image = document.createElement("img");

        newCard.className = "card";
        newCard.style.width = "18rem";
        newCard.style.margin = "0 10px 10px 0";
        newCard.style.display = "inline-block";

        cardBody.className = "card-body";

        imageTitle.className = "card-title";
        imageTitle.innerHTML = img.title;

        image.className = "card-img-top";
        image.src = `https://live.staticflickr.com/${img.server}/${img.id}_${img.secret}_w.jpg`;

        // add found aspects to new card
        newCard.appendChild(image);
        newCard.appendChild(cardBody);
        cardBody.appendChild(imageTitle);
        content.appendChild(newCard);
      });
    });
}


// for reloading when bottom of page
function checkScroll() {
  var content = document.getElementById("content");

  curScrollHeight = content.scrollHeight;
  curScrollTop = content.scrollTop;

  if (curScrollTop + parseInt(content.style.height) >= curScrollHeight) {
    makeApiCall();
  }
}