#!/bin/bash
# Authors : Ryan Taylor
# Date: 09/20/2020

cp /var/log/syslog ~
echo -en '\n' > ~/error_log_check.txt
egrep -i "error" ~/syslog >> ~/error_log_check.txt
/usr/sbin/sendmail ryta4737@colorado.edu < ~/error_log_check.txt